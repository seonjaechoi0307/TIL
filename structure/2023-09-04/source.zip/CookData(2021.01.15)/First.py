print("IT CookBook for Beginner")
print("자료구조와 알고리즘을 학습 중입니다.")
